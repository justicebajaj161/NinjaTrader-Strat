#region Using declarations
using System;
using NinjaTrader.Cbi;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript.Strategies;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
using System.Windows.Media;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class NASDAQ100PeakHoursStrategy : Strategy
    {
        // Input parameters
        private int longTermEmaLength = 21;
        private int shortTermEmaLength = 9;
        private int rsiLength = 14;
        private int atrLength = 14;
        private double trailStopATRMultiplier = 1.5;
        private double initialStopLossMultiplier = 0.5;
        private int timeExitBars = 20;
        private double maxDrawdown = 0.20; // 20% drawdown limit

        // Indicators
        private EMA longTermEma;
        private EMA shortTermEma;
        private RSI rsi;
        private ATR atr;

        // Custom VWAP Variables
        private double cumulativeVolume = 0;
        private double cumulativePriceVolume = 0;
        private double sessionVolume = 0;
        private double sessionPriceVolume = 0;

        // Variables to track trade entry
        private double longEntryPrice;
        private double shortEntryPrice;
        private int longEntryBar = -1;
        private int shortEntryBar = -1;
        private double initialCapital;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                // Set strategy defaults
                Description = "NASDAQ 100 Peak Hours Strategy";
                Name = "NASDAQ100PeakHoursStrategy";
                Calculate = Calculate.OnEachTick; // Intraday strategy
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                DefaultQuantity = 1;
                IsExitOnSessionCloseStrategy = false;
                IsInstantiatedOnEachOptimizationIteration = true;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
            }
            else if (State == State.Configure)
            {
                // Add required indicators
                longTermEma = EMA(Close, longTermEmaLength);
                shortTermEma = EMA(Close, shortTermEmaLength);
                rsi = RSI(Close, rsiLength, 3);
                atr = ATR(atrLength);

                // Add indicators to the chart for visualization
                AddChartIndicator(longTermEma);
                AddChartIndicator(shortTermEma);
                AddChartIndicator(rsi);
                AddChartIndicator(atr);

                initialCapital = Account.Get(AccountItem.CashValue, Currency.UsDollar);
            }
        }

        // Custom VWAP Calculation
        private double CalculateVWAP()
        {
            // Reset VWAP values at the start of a new session
            if (Bars.IsFirstBarOfSession)
            {
                sessionVolume = 0;
                sessionPriceVolume = 0;
            }

            // Accumulate volume and price-volume product for current bar
            double volume = Volume[0];
            double typicalPrice = (High[0] + Low[0] + Close[0]) / 3;

            sessionVolume += volume;
            sessionPriceVolume += typicalPrice * volume;

            // Return the VWAP value
            if (sessionVolume != 0)
                return sessionPriceVolume / sessionVolume;
            else
                return Close[0]; // Default to the current close price if no volume
        }

        protected override void OnBarUpdate()
        {
            if (CurrentBars[0] < 21) return; // Ensure enough data to calculate

            // Define session times (Regular and Extended hours)
            DateTime sessionStart = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 9, 0, 0);
            DateTime sessionEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 11, 30, 0);
            DateTime extendedStart = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 8, 0, 0);
            DateTime extendedEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 16, 0, 0);

            //     DateTime sessionStart = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 19, 30, 0);
            // DateTime sessionEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 22, 00, 0);
            // DateTime extendedStart = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 18, 30, 0);
            // DateTime extendedEnd = new DateTime(Time[0].Year, Time[0].Month, Time[0].Day, 02, 30, 0);

            bool isTradeWindow = Time[0] >= extendedStart && Time[0] <= extendedEnd;
            bool volatilityFilter = atr[0] > SMA(atr, 20)[0];

            // Calculate VWAP for the current bar
            double vwap = CalculateVWAP();

            // Long and Short Conditions
            bool longCondition = (Close[0] > shortTermEma[0]) && (shortTermEma[0] > longTermEma[0]) &&
                                 shortTermEma[0] > shortTermEma[1] && longTermEma[0] > longTermEma[1] &&
                                 rsi[0] > 50 && Close[0] > vwap && isTradeWindow &&
                                 Time[0] >= sessionStart && Time[0] <= sessionEnd && volatilityFilter;

            bool shortCondition = (Close[0] < shortTermEma[0]) && (shortTermEma[0] < longTermEma[0]) &&
                                  shortTermEma[0] < shortTermEma[1] && longTermEma[0] < longTermEma[1] &&
                                  rsi[0] < 50 && Close[0] < vwap && isTradeWindow &&
                                  Time[0] >= sessionStart && Time[0] <= sessionEnd && volatilityFilter;

            // Entry logic
            if (longCondition && Position.MarketPosition == MarketPosition.Flat)
            {
                EnterLong();
                longEntryBar = CurrentBar;
                longEntryPrice = Close[0];
            }
            if (shortCondition && Position.MarketPosition == MarketPosition.Flat)
            {
                EnterShort();
                shortEntryBar = CurrentBar;
                shortEntryPrice = Close[0];
            }

            // Trailing stop and break-even logic
            double trailStopLong = atr[0] * trailStopATRMultiplier;
            double trailStopShort = atr[0] * trailStopATRMultiplier;
            double breakEvenTrigger = 1.5 * atr[0];

            if (Position.MarketPosition == MarketPosition.Long)
            {
                SetTrailStop(CalculationMode.Price, longEntryPrice - trailStopLong);
                if (Close[0] > longEntryPrice + breakEvenTrigger)
                {
                    SetStopLoss(CalculationMode.Price, longEntryPrice);
                }
            }
            if (Position.MarketPosition == MarketPosition.Short)
            {
                SetTrailStop(CalculationMode.Price, shortEntryPrice + trailStopShort);
                if (Close[0] < shortEntryPrice - breakEvenTrigger)
                {
                    SetStopLoss(CalculationMode.Price, shortEntryPrice);
                }
            }

            // Exit after 20 bars
            if (Position.MarketPosition == MarketPosition.Long && CurrentBar - longEntryBar >= timeExitBars)
            {
                ExitLong();
                longEntryBar = -1;
            }
            if (Position.MarketPosition == MarketPosition.Short && CurrentBar - shortEntryBar >= timeExitBars)
            {
                ExitShort();
                shortEntryBar = -1;
            }

            // Trend reversal exit
            bool trendReversalExitLong = shortTermEma[0] < longTermEma[0];
            bool trendReversalExitShort = shortTermEma[0] > longTermEma[0];

            if (Position.MarketPosition == MarketPosition.Long && trendReversalExitLong)
            {
                ExitLong();
            }
            if (Position.MarketPosition == MarketPosition.Short && trendReversalExitShort)
            {
                ExitShort();
            }

            // Max drawdown logic (close all positions if drawdown exceeds the limit)
            double currentEquity = Account.Get(AccountItem.CashValue, Currency.UsDollar);
            if (currentEquity < initialCapital * (1 - maxDrawdown))
            {
                ExitLong();
                ExitShort();
            }
        }
    }
}
