/// <summary>
/// Coded by trguila July 2024. Email: trguila@yahoo.com for improvements
/// MIT License/OPEN SOURCE LICENSE
/// Copyright(C) 2024, ninjatraderstrategiesmarket.com
/// We're passionate about creating valuable trading tools for the community.
/// Your donations help us develop and share more innovative strategies.
/// If you find this script helpful, please consider a donation via the website ninjatraderstrategiesmarket.com.
///Join our community https://discord.gg/MK4NZP8s and contribute to helping traders
/// </summary>
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds Strategies in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Strategies
{
    public class StrategyTripleThreat : Strategy
    {
        private MyDonchianChannel DonchianChannel1;
        private MySMA SMA1;
        private MyParabolicSAR ParabolicSAR1;
        private MyRSI RSI1;
        private MyBollinger Bollinger1;
        private MyStochastics Stochastics1;
        private MyVOL VOL1;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Profit Target (Ticks)", Order = 1, GroupName = "Parameters")]
        public int ProfitTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Stop Loss (Ticks)", Order = 2, GroupName = "Parameters")]
        public int StopLossTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Trail Stop (Ticks)", Order = 3, GroupName = "Parameters")]
        public int TrailStopTicks { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = @"Strategy Triple Threat";
                Name = "StrategyTripleThreat";
                Calculate = Calculate.OnBarClose;
                EntriesPerDirection = 1;
                EntryHandling = EntryHandling.AllEntries;
                IsExitOnSessionCloseStrategy = true;
                ExitOnSessionCloseSeconds = 30;
                IsFillLimitOnTouch = false;
                MaximumBarsLookBack = MaximumBarsLookBack.TwoHundredFiftySix;
                OrderFillResolution = OrderFillResolution.Standard;
                Slippage = 0;
                StartBehavior = StartBehavior.WaitUntilFlat;
                TimeInForce = TimeInForce.Gtc;
                TraceOrders = false;
                RealtimeErrorHandling = RealtimeErrorHandling.StopCancelClose;
                StopTargetHandling = StopTargetHandling.PerEntryExecution;
                BarsRequiredToTrade = 20;
                IsInstantiatedOnEachOptimizationIteration = true;

                ProfitTargetTicks = 200;
                StopLossTicks = 200;
                TrailStopTicks = 200;
            }
            else if (State == State.Configure)
            {
                // Configure your strategy here
            }
            else if (State == State.DataLoaded)
            {
                DonchianChannel1 = MyDonchianChannel(Close, 14);
                SMA1 = MySMA(Close, 200);
                ParabolicSAR1 = MyParabolicSAR(Close, 0.02, 0.2, 0.02);
                RSI1 = MyRSI(Close, 14, 3);
                Bollinger1 = MyBollinger(Close, 2, 14);
                Stochastics1 = MyStochastics(Close, 7, 14, 3);
                VOL1 = MyVOL(Close);

                SetProfitTarget("", CalculationMode.Ticks, ProfitTargetTicks);
                SetStopLoss("", CalculationMode.Ticks, StopLossTicks, false);
                SetTrailStop("", CalculationMode.Ticks, TrailStopTicks, false);
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0)
                return; // Process only completed bars

            // Condition to take an entry only if VOL1 > 50 and DonchianChannel1 is not showing any extreme volatility
            bool validVolatility = VOL1[0] > 50 && (DonchianChannel1.Upper[0] - DonchianChannel1.Lower[0]) / DonchianChannel1.Mean[0] < 0.05;

            if (!validVolatility)
                return;

            // *** Refined Long Entry Logic ***
            bool isLongTrend = Close[0] > SMA1[0]; // Trend filter (above 200-day SMA)
            bool isLongSignal =
                (RSI1.Default[0] >= 20 && RSI1.Default[0] <= 30) && // Strong oversold
                (CrossBelow(Close, ParabolicSAR1, 1) && RSI1.Default[0] < 50) || // Parabolic SAR reversal with RSI confirmation
                (CrossBelow(Low, Bollinger1.Lower, 1) && Stochastics1.D[0] < 20); // Bollinger Band breakout with Stochastics confirmation

            if (isLongTrend && isLongSignal && Position.MarketPosition == MarketPosition.Flat)
            {
                EnterLong(Convert.ToInt32(DefaultQuantity)); // Use DefaultQuantity from strategy settings
            }

            // *** Refined Short Entry Logic ***
            bool isShortTrend = Close[0] < SMA1[0]; // Trend filter (below 200-day SMA)
            bool isShortSignal =
                (RSI1.Default[0] >= 70 && RSI1.Default[0] <= 80) && // Strong overbought
                (CrossAbove(ParabolicSAR1, Close, 1) && RSI1.Default[0] > 50) || // Parabolic SAR reversal with RSI confirmation
                (CrossAbove(High, Bollinger1.Upper, 1) && Stochastics1.D[0] > 80); // Bollinger Band breakout with Stochastics confirmation

            if (isShortTrend && isShortSignal && Position.MarketPosition == MarketPosition.Flat)
            {
                EnterShort(Convert.ToInt32(DefaultQuantity));
            }
        }
    }
}
