/// <summary>
/// Coded by trguila July 2024. Email: trguila@yahoo.com for improvements
/// MIT License/OPEN SOURCE LICENSE
/// Copyright(C) 2024, ninjatraderstrategiesmarket.com
/// We're passionate about creating valuable trading tools for the community.
/// Your donations help us develop and share more innovative strategies.
/// If you find this script helpful, please consider a donation via the website ninjatraderstrategiesmarket.com.
/// </summary>

#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

namespace NinjaTrader.NinjaScript.Strategies
{
    public class StrategyEagleEyePeakHoursTradingNQ : Strategy
    {
        private MyTwoEMA MyTwoEMA1, MyTwoEMA2;
        private MyTwoRSI MyTwoRSI1;
        private MyTwoVWAP8 MyTwoVWAP81;
        private MyTwoSMA MyTwoSMA1, MyTwoSMA2;
        private MyTwoATR MyTwoATR1;
        private MyTwoVOL MyTwoVOL1;

        private double trailStop, breakEvenTrigger;
        private int longEntryBar = -1, shortEntryBar = -1;
        private double longEntryPrice = 0.0, shortEntryPrice = 0.0;
        private const int timeExitBars = 20, maxDrawdown = 20;
        private double maxDrawdownPercent = 0.0, highestProfit = 0.0;

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Profit Target (Ticks)", Order = 1, GroupName = "Parameters")]
        public int ProfitTargetTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Trail Stop (Ticks)", Order = 3, GroupName = "Parameters")]
        public int TrailStopTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, int.MaxValue)]
        [Display(Name = "Contracts", Order = 4, GroupName = "Parameters")]
        public int Contracts { get; set; }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                ProfitTargetTicks = 200;
                TrailStopTicks = 200;
                Contracts = 1;
                Calculate = Calculate.OnEachTick;
            }
            else if (State == State.DataLoaded)
            {
                MyTwoEMA1 = MyTwoEMA(Close, 9);
                MyTwoEMA2 = MyTwoEMA(Close, 21);
                MyTwoRSI1 = MyTwoRSI(Close, 14, 3);
                MyTwoVWAP81 = MyTwoVWAP8(Close);
                MyTwoSMA1 = MyTwoSMA(MyTwoATR(14), 20);
                MyTwoSMA2 = MyTwoSMA(MyTwoVOL(Close), 20);
                MyTwoVOL1 = MyTwoVOL(Close);
                MyTwoATR1 = MyTwoATR(14);

                SetProfitTarget("", CalculationMode.Ticks, ProfitTargetTicks);
                SetTrailStop("", CalculationMode.Ticks, TrailStopTicks, false);
            }
        }

        protected override void OnBarUpdate()
        {
            if (BarsInProgress != 0 || CurrentBars[0] < 1) return;

            bool volatilityFilter = MyTwoATR1[0] > MyTwoSMA1[0] && Volume[0] > MyTwoSMA2[0];
            trailStop = 1.5 * MyTwoATR1[0];
            breakEvenTrigger = 1.5 * MyTwoATR1[0];

            if (Position.MarketPosition == MarketPosition.Long)
                maxDrawdownPercent = ((Close[0] - Position.AveragePrice) / Position.AveragePrice) * 100;

            if (Position.MarketPosition == MarketPosition.Short)
                maxDrawdownPercent = ((Position.AveragePrice - Close[0]) / Position.AveragePrice) * 100;

            highestProfit = Math.Max(highestProfit, maxDrawdownPercent);

            if (IsPeakHours() && Position.MarketPosition == MarketPosition.Flat && volatilityFilter)
            {
                if (IsLongConditionMet())
                {
                    EnterLong(Contracts);
                    longEntryBar = CurrentBar;
                    longEntryPrice = Close[0];
                }
                else if (IsShortConditionMet())
                {
                    EnterShort(Contracts);
                    shortEntryBar = CurrentBar;
                    shortEntryPrice = Close[0];
                }
            }

            ManagePositions();
        }

        private bool IsPeakHours()
        {
            int currentTime = ToTime(Time[0]);
            return currentTime > ToTime(19, 10, 0) && currentTime < ToTime(23, 30, 0);
        }

        private bool IsLongConditionMet()
        {
            return Close[0] > MyTwoEMA1[0] && MyTwoEMA1[0] > MyTwoEMA2[0] && MyTwoRSI1.Avg[0] > 50 && Close[0] > MyTwoVWAP81[0] && MyTwoVOL1[0] > MyTwoVOL1[1];
        }

        private bool IsShortConditionMet()
        {
            return Close[0] < MyTwoEMA1[0] && MyTwoEMA1[0] < MyTwoEMA2[0] && MyTwoRSI1.Avg[0] < 50 && Close[0] < MyTwoVWAP81[0] && MyTwoVOL1[0] > MyTwoVOL1[1];
        }

        private void ManagePositions()
        {
            if (Position.MarketPosition == MarketPosition.Long)
            {
                if (Close[0] < (longEntryPrice - trailStop) ||
                    Close[0] > (longEntryPrice + breakEvenTrigger) ||
                    CurrentBar - longEntryBar >= timeExitBars ||
                    MyTwoEMA1[0] < MyTwoEMA2[0] ||
                    highestProfit - maxDrawdownPercent >= maxDrawdown)
                {
                    ExitLong();
                }
            }
            else if (Position.MarketPosition == MarketPosition.Short)
            {
                if (Close[0] > (shortEntryPrice + trailStop) ||
                    Close[0] < (shortEntryPrice - breakEvenTrigger) ||
                    CurrentBar - shortEntryBar >= timeExitBars ||
                    MyTwoEMA1[0] > MyTwoEMA2[0] ||
                    highestProfit - maxDrawdownPercent >= maxDrawdown)
                {
                    ExitShort();
                }
            }
        }
    }
}
