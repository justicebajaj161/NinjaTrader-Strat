// Copyright (C) 2024, NinjaTrader LLC <www.ninjatrader.com>.
// NinjaTrader reserves the right to modify or overwrite this NinjaScript component with each release.
//
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

// This namespace holds indicators in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.Indicators
{
	/// <summary>
	/// Volume is simply the number of shares (or contracts) traded during a specified time frame (e.g. hour, day, week, month, etc).
	/// </summary>
	public class MyTwoVOL : Indicator
	{
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description					= Custom.Resource.NinjaScriptIndicatorDescriptionVOL;
				Name						= Custom.Resource.NinjaScriptIndicatorNameVOL;
				BarsRequiredToPlot			= 0;
				Calculate					= Calculate.OnEachTick;
				DrawOnPricePanel			= false;
				IsSuspendedWhileInactive	= true;

				AddPlot(new Stroke(Brushes.DodgerBlue, 2),	PlotStyle.Bar,	Custom.Resource.VOLVolume);
				AddLine(Brushes.DarkGray, 0,			Custom.Resource.NinjaScriptIndicatorZeroLine);
			}
			else if (State == State.Historical)
			{
				if (Calculate == Calculate.OnPriceChange)
				{
					Draw.TextFixed(this, "NinjaScriptInfo", string.Format(Custom.Resource.NinjaScriptOnPriceChangeError, Name), TextPosition.BottomRight);
					Log(string.Format(Custom.Resource.NinjaScriptOnPriceChangeError, Name), LogLevel.Error);
				}
			}
		}

		protected override void OnBarUpdate()
		{
			Value[0] = Instrument.MasterInstrument.InstrumentType == InstrumentType.CryptoCurrency ? Core.Globals.ToCryptocurrencyVolume((long)Volume[0]) : Volume[0];
		}
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private MyTwoVOL[] cacheMyTwoVOL;
		public MyTwoVOL MyTwoVOL()
		{
			return MyTwoVOL(Input);
		}

		public MyTwoVOL MyTwoVOL(ISeries<double> input)
		{
			if (cacheMyTwoVOL != null)
				for (int idx = 0; idx < cacheMyTwoVOL.Length; idx++)
					if (cacheMyTwoVOL[idx] != null &&  cacheMyTwoVOL[idx].EqualsInput(input))
						return cacheMyTwoVOL[idx];
			return CacheIndicator<MyTwoVOL>(new MyTwoVOL(), input, ref cacheMyTwoVOL);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.MyTwoVOL MyTwoVOL()
		{
			return indicator.MyTwoVOL(Input);
		}

		public Indicators.MyTwoVOL MyTwoVOL(ISeries<double> input )
		{
			return indicator.MyTwoVOL(input);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.MyTwoVOL MyTwoVOL()
		{
			return indicator.MyTwoVOL(Input);
		}

		public Indicators.MyTwoVOL MyTwoVOL(ISeries<double> input )
		{
			return indicator.MyTwoVOL(input);
		}
	}
}

#endregion
